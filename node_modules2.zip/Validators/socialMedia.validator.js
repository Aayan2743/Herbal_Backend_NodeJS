import { body } from "express-validator";

export const updateSocialMediaValidator = [
  body("linkedin").optional().isURL().withMessage("Invalid LinkedIn URL"),
  body("dribbble").optional().isURL().withMessage("Invalid Dribbble URL"),
  body("instagram").optional().isURL().withMessage("Invalid Instagram URL"),
  body("twitter").optional().isURL().withMessage("Invalid Twitter/X URL"),
  body("youtube").optional().isURL().withMessage("Invalid YouTube URL"),
];
