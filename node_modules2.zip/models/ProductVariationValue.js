import { DataTypes } from "sequelize";
import sequelize from "../config/dbconfig.js";
import ProductVariation from "./ProductVariation.js";

const ProductVariationValue = sequelize.define(
  "ProductVariationValue",
  {
    variation_id: {
      type: DataTypes.INTEGER,
      allowNull: false,
    },
    value: {
      type: DataTypes.STRING,
      allowNull: false,
    },
    color_code: {
      type: DataTypes.STRING,
      allowNull: true,
    },
  },
  {
    tableName: "product_variation_values",
    timestamps: true,
    underscored: true,
  }
);

ProductVariation.hasMany(ProductVariationValue, {
  foreignKey: "variation_id",
  as: "values",
});
ProductVariationValue.belongsTo(ProductVariation, {
  foreignKey: "variation_id",
});

export default ProductVariationValue;
